<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form fields
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $type = $_POST['type'];
    $subtype = $_POST['subtype'];
    $pricing = $_POST['pricing'];
    $requirements = $_POST['requirements'];

    // Create the email message
    $to = "jodicksonjoshua@gmail.com";
    $subject = "New Order";
    $message = "Name: $name\n";
    $message .= "Email: $email\n";
    $message .= "Phone: $phone\n";
    $message .= "Type: $type\n";
    $message .= "Subtype: $subtype\n";
    $message .= "Pricing: $pricing\n";
    $message .= "Requirements: $requirements\n";

    // Set additional headers
    $headers = "From: $name <$email>";

    // Send the email
    if (mail($to, $subject, $message, $headers)) {
        echo "Your order has been submitted successfully.";
    } else {
        echo "Oops! Something went wrong. Please try again later.";
    }
}
?>
