'use strict';



/**
 * add Event on elements
 */

const addEventOnElem = function (elem, type, callback) {
  if (elem.length > 1) {
    for (let i = 0; i < elem.length; i++) {
      elem[i].addEventListener(type, callback);
    }
  } else {
    elem.addEventListener(type, callback);
  }
}

document.addEventListener("DOMContentLoaded", function() {
  const popup = document.getElementById("popup");
  const acceptBtn = document.getElementById("acceptBtn");
  const declineBtn = document.getElementById("declineBtn");

  acceptBtn.addEventListener("click", function() {
    // Accept action
    popup.style.right = "-1000px"; // Hide the popup
  });

  declineBtn.addEventListener("click", function() {
    // Decline action
    // You can customize this behavior as per your requirement
    popup.style.right = "-1000px"; // Hide the popup
  });

  // Show the popup initially
  popup.style.right = "0";
});

// Replace with your own YouTube video ID
const videoId = "watch?v=T33NN_pPeNI";

// Load the YouTube IFrame Player API code asynchronously.
const tag = document.createElement("script");
tag.src = "https://www.youtube.com/iframe_api";
const firstScriptTag = document.getElementsByTagName("script")[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// Create YouTube player when the API code is loaded.
let player;
function onYouTubeIframeAPIReady() {
  player = new YT.Player("player", {
    height: "700",
    width: "1000",
    videoId: videoId,
    playerVars: {
      autoplay: 1,
      controls: 1,
      rel: 0,
      modestbranding: 1,
    },
    events: {
      onReady: onPlayerReady,
    },
  });
}

function onPlayerReady(event) {
  event.target.playVideo();
}

const youtubeBtn = document.getElementById("youtubeBtn");
const youtubePopup = document.getElementById("youtubePopup");
const closeBtn = document.getElementById("closeBtn");

youtubeBtn.addEventListener("click", function() {
  youtubePopup.style.display = "block";
});

closeBtn.addEventListener("click", function() {
  player.stopVideo();
  youtubePopup.style.display = "none";
});




/**
 * navbar toggle
 */

const navbar = document.querySelector("[data-navbar]");
const navTogglers = document.querySelectorAll("[data-nav-toggler]");
const navbarLinks = document.querySelectorAll("[data-nav-link]");
const overlay = document.querySelector("[data-overlay]");

const toggleNavbar = function () {
  navbar.classList.toggle("active");
  overlay.classList.toggle("active");
}

addEventOnElem(navTogglers, "click", toggleNavbar);

const closeNavbar = function () {
  navbar.classList.remove("active");
  overlay.classList.remove("active");
}

addEventOnElem(navbarLinks, "click", closeNavbar);



/**
 * header & back top btn show when scroll down to 100px
 */

const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

const headerActive = function () {
  if (window.scrollY > 80) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
}

addEventOnElem(window, "scroll", headerActive);

var tab_lists = document.querySelectorAll(".tabs_list ul li");
var tab_items = document.querySelectorAll(".tab_item"); 

tab_lists.forEach(function(list){
  list.addEventListener("click", function(){
    var tab_data = list.getAttribute("data-tc");
    
    tab_lists.forEach(function(list){
      list.classList.remove("active");
    });
    list.classList.add("active");
    
    tab_items.forEach(function(item){
      var tab_class = item.getAttribute("class").split(" ");
      if(tab_class.includes(tab_data)){
        item.style.display = "block";
      }
      else{
        item.style.display = "none";
      }
      
    })
    
  })
})

// Get the control bar and buttons
const controlBar = document.getElementById("music-control-bar");
const playPauseBtn = document.getElementById("play-pause-btn");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");

// Dummy list of songs
const songs = ["Juice-WRLD-Cursed-Heart-(Celebnob.com).mp3", "Drake_Ft_Lil_Durk_-_Laugh_Now_Cry_Later.mp3", "Drake-Toosie-Slide.mp3", "Song 4"];
let currentSongIndex = 0;

// Audio element
const audio = new Audio();
audio.src = songs[currentSongIndex];

// Function to update the current song displayed
function updateCurrentSong() {
  document.getElementById("current-song").innerText = songs[currentSongIndex];
}

// Function to play/pause the song
function playPauseSong() {
  if (audio.paused) {
    audio.play();
    playPauseBtn.classList.remove("bx-play");
    playPauseBtn.classList.add("bx-pause");
  } else {
    audio.pause();
    playPauseBtn.classList.remove("bx-pause");
    playPauseBtn.classList.add("bx-play");
  }
}

// Function to play the previous song
function playPrevSong() {
  currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
  audio.src = songs[currentSongIndex];
  updateCurrentSong();
  playPauseSong(); // Start playing the new song
}

// Function to play the next song
function playNextSong() {
  currentSongIndex = (currentSongIndex + 1) % songs.length;
  audio.src = songs[currentSongIndex];
  updateCurrentSong();
  playPauseSong(); // Start playing the new song
}

// Event listeners for buttons
playPauseBtn.addEventListener("click", playPauseSong);
prevBtn.addEventListener("click", playPrevSong);
nextBtn.addEventListener("click", playNextSong);

// Show the control bar
controlBar.style.left = "0";

// Start playing the first song
updateCurrentSong();
audio.play(); // Start playing the first song

// Hide the control bar after 10 seconds
setTimeout(() => {
  controlBar.style.left = "-200px"; // Assuming the width of control bar is 200px
}, 10000);

